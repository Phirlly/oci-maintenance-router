variable "operator_email" {
  type        = string
  nullable    = false
  default     = ""
  description = "Operator email, required in LIVE. Apply in PREVIEW or PAUSED, confirm OCI's email, then select TEST. Clearing it removes this stack's subscription."
  validation {
    condition = var.operator_email == "" || (
      can(regex("^[^@\\s\\p{Z}\\p{Cc}]+@[^@\\s\\p{Z}\\p{Cc}]+$", var.operator_email)) &&
      length(regexall(".", var.operator_email)) <= 512
    )
    error_message = "Operator email must be one address without whitespace or control characters, at most 512 Unicode characters; leave empty to omit operator setup."
  }
}
variable "operator_test_run" {
  type        = number
  default     = null
  description = "Explicit operator test number in TEST with an email and in LIVE; unchanged reuses its saved result."
}
variable "operator_receipt_code" {
  type        = string
  nullable    = false
  default     = ""
  description = "Confirmation code from the received operator email, required in LIVE. Keep test numbers unchanged and also supply the PagerDuty confirmation code."
}
